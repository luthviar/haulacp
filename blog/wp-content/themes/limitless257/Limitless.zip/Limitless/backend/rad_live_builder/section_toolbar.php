<?php
/**
 * Show Section Area Toolbar
 */

?>
<div class="rad_section_toolbar clearfix">
 	 <a href="" class="rad_section_edit"><i class="ioa-front-icon  edit-1icon-"></i></a>
 	 <a href="" class="rad_section_clone"><i class="ioa-front-icon  docsicon-"></i></a>
	 <!-- <a href="" class="rad_section_export_trigger"><i class="ioa-front-icon  export-alticon-"></i></a> -->
	 <a href="" class="rad_section_save_library"><i class="ioa-front-icon folder-2icon-"></i></a>
 	 <a href="" class="rad_section_delete"><i class="ioa-front-icon cancel-2icon-"></i></a>
</div>

<i href="" class="section-sortable-handle ioa-front-icon resize-vertical-1icon-"></i>