<?php
/**
 * RAD Help Template -- Shows when Buider is empty or for a new page.
 **/
?>

<div class="rad-help clearfix">
	
	<div class="help-drop-area">
		<h3><?php _e('Drag a widget from right sidebar to begin the journey :)','ioa') ?></h3>	
	</div>

</div>

