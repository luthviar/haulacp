<?php
/**
 * Content wrappers -- Global Wrappers are by default added in IOA Framework
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

?>
